﻿using System;
using System.Collections.Generic;

namespace trabalho_1_bimestre
{
    

    class Program
    {
        private static List<Objeto> listaObjeto = new List<Objeto>();

        static void Main(string[] args)
        {

            bool continua = true;
        start:
            do
            {
                Console.WriteLine("menu cadastro!");
                Console.WriteLine("1 incluir");
                Console.WriteLine("2 alterar");
                Console.WriteLine("3 excluir");
                Console.WriteLine("4 listar");
                Console.WriteLine("5 pesquisar");
                Console.WriteLine("9 sair");
                Console.WriteLine("QuantIdade de Objeto" + listaObjeto.Count);
                Console.WriteLine("qual a sua opção");
                string opc = Console.ReadLine();


                switch (opc)
                {

                    case "1":
                        Console.WriteLine();
                        Console.WriteLine("incluir");
                        listaObjeto.Add(incluir());

                        break;
                    case "2":
                        Console.WriteLine("alterar");
                        listaObjeto.Add(alterar());
                        Console.Clear();
                        Console.WriteLine("Alterar");

                        if (listaObjeto.Count == 0)
                        {
                            Console.WriteLine("Nao há nada cadastrado.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        else
                        {
                            Console.Write("Digite a Id  que deseja alterar: ");
                            string modificar = Console.ReadLine();
                            Objeto auxiliador = listaObjeto.Find(x => x.Id == modificar);
                            if (auxiliador == null)
                            {
                                Console.WriteLine("nao existe.");
                                Console.ReadLine();
                                Console.Clear();
                            }
                            if (auxiliador != null)
                            {
                                Console.Write("Digita sua nova Id: ");

                                Objeto alterar = listaObjeto.Find(x => x.Id == modificar);
                                alterar.Id = Console.ReadLine();

                                Console.Write("Digite o novo nome : ");
                                Objeto alterar1 = listaObjeto.Find(x => x.Id == alteracao);
                                alterar.Nome = Console.ReadLine();

                                Console.Write("Digite o novo Fone: ");
                                Objeto alterar3 = listaObjeto.Find(x => x.Id == alteracao);
                                alterar.Fone = Console.ReadLine();
                                Console.ReadLine();


                                Console.Write("Digite o nova data: ");
                                Objeto alterar4 = listaObjeto.Find(x => x.Id == alteracao);
                                alterar.Data = Console.ReadLine();
                                Console.ReadLine();

                                Console.Write("Digite o novo Peso: ");
                                Objeto alterar5 = listaObjeto.Find(x => x.Id == alteracao);
                                alterar.Peso = float.Parse(Console.ReadLine());
                                Console.ReadLine();

                            }
                        }
                        break;


                    case "3":


                        Console.WriteLine("Excluir");

                        if (listaObjeto.Count == 0)
                        {
                            Console.WriteLine("Desculpe, não há nada cadastrado no sistema para você excluir.");
                        }
                        else
                        {
                            Console.Write("Qual ID deseja excluir? ");
                            string guardar = Console.ReadLine();
                            string escolha;
                            Console.Write("quer excluir Sim/Não ");
                            escolha = Console.ReadLine();

                            if (escolha == "Sim")
                            {
                                Console.WriteLine("modificando: ");
                            }
                            Console.Clear();
                            if (escolha == "Não")
                            {
                                Console.WriteLine("nao houve alteraçao. ");
                                Console.WriteLine();

                                break;
                            }
                            if (listaObjeto.Remove(listaObjeto.Find(x => x.Id == guardar)))
                            {
                                Console.WriteLine("Excluído com sucesso");
                            }
                            else
                            {
                                Console.WriteLine("nada encontrado!");
                            }
                        }
                        Console.ReadLine();
                        Console.Clear();
                        break;


                    //case "4":
                        Console.WriteLine("listar");
                        break;

                   // case "5":
                        Console.WriteLine("pesquisar");
                        if (listaObjeto.Count == 0)
                        {
                            Console.WriteLine("Desculpe, não há nada cadastrado no sistema para você excluir.");
                        }
                        else
                        {
                            Console.Write("Qual ID deseja excluir? ");
                            string guardar = Console.ReadLine();
                            string escolha;
                            Console.Write("quer excluir Sim/Não ");
                            escolha = Console.ReadLine();

                            if (escolha == "Sim")
                            {
                                Console.WriteLine("modificando: ");
                            }
                            Console.Clear();
                            if (escolha == "Não")
                            {
                                Console.WriteLine("nao houve alteraçao. ");
                                Console.WriteLine();

                                break;
                            }
                            if (listaObjeto.Remove(listaObjeto.Find(x => x.Id == guardar)))
                            {
                                Console.WriteLine("Excluído com sucesso");
                            }
                            else
                            {
                                Console.WriteLine("nada encontrado!");
                            }
                        }
                        Console.ReadLine();
                        Console.Clear();
                        break;

                    case "9":

                        continua = false;
                        Console.WriteLine("tem certeza que deseja sair pressione a tecla s, se não digite n");
                        string quersair;
                        quersair = Console.ReadLine();

                        if (quersair == "s")
                        {
                            Console.WriteLine("Sair: Aplicação encerrada.");

                            Console.ReadLine();

                        }
                        if (quersair == "n")
                        {

                            goto start;
                        }
                        break;



                    default:
                        Console.WriteLine("opção não existente");
                        break;
                }

            } while (continua);
            Console.WriteLine("aplicação encerrada");
            Console.Read();


        }

        private static Objeto incluir()
        {

            Objeto objeto = new Objeto();

            Console.Write("Id: ");
            objeto.Id = Console.ReadLine();

            Console.Write("Nome: ");
            objeto.Nome = Console.ReadLine();

            Console.Write("Fone: ");
            objeto.Fone = Console.ReadLine();

            Console.Write("Data: ");
            objeto.Data = Console.ReadLine();

            Console.Write("Peso: ");
            objeto.Data = Console.ReadLine();



            return objeto;
        }

        private static Objeto alterar()
        {
            Objeto objeto = new Objeto();


            return objeto;
        }

        private static Objeto excluir()
        {
            Objeto objeto = new Objeto();

            return objeto;
        }
        private static Objeto pesquisar()
        {

            Objeto objeto = new Objeto();

            Console.Write("Id: ");
            objeto.Id = Console.ReadLine();

            Console.Write("Nome: ");
            objeto.Nome = Console.ReadLine();

            Console.Write("Fone: ");
            objeto.Fone = Console.ReadLine();

            return objeto;
        }




    }






}
