﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prova
{
    class Objeto
    {
        

         public string Id { set; get; }
        public string Nome { set; get; }
        public string Fone { set; get; }
        public string Data { set; get; }
        public float Peso { set; get; }

        public override string ToString()
        {
            return "Id: " + Id + ", Nome: " + Nome + ", Fone: " + Fone;
        }

    }


}


    

